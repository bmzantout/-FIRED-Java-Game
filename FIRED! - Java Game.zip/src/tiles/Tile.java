package tiles;

import java.awt.image.BufferedImage;

public class Tile {
	
	public BufferedImage tileImage;
	public boolean collide = false;
}
