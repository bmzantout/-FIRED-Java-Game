package main;

import javax.swing.JFrame;
import javax.swing.JPanel;
import characters.QuestionPanel;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MainMethod main_method = new MainMethod();
		main_method.startTheGame();
		
	}

}



















